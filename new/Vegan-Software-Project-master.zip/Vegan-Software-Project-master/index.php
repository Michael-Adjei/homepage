<?php
session_start();
?>


    <!HEADER BEGINS>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Homepage</title>
        <link type="text/css" rel="stylesheet" href="css/style.css">
    </head>
	
    <body class="homepage_body">
    <header>
        <?php include ("Header.php"); ?>
    </header>
    <div class="header_homepage">

<!--        <ul id="navbar">-->
<!--            <li id="there"><a href="#">Home</a> </li>-->
<!--            <li><a href="#">About Us</a> </li>-->
<!--            <li><a href="#">Recipe</a> </li>-->
<!--            <li><a href="#">Products</a> </li>-->
<!--            <li><a href="#">Contact Us</a> </li>-->
<!--            <li><a href="login.php">Logout</a> </li>-->
<!--        </ul>-->
        <p id="info">

            vegetarian for five years before that. The difference between vegetarians and vegans is that vegetarians
            don’t eat any animal flesh (beef, chicken, fish, etc.), but vegans go further, and also don’t consume or
            use anything that comes from an animal (egg, dairy, leather, fur, etc.
            <br><br>
            There are different varieties of vegan diets. The most common include:
            Whole-food vegan diet: A diet based on a wide variety of whole plant foods such as fruits, vegetables,
            whole grains, legumes, nuts and seeds.
            Raw-food vegan diet: A vegan diet based on raw fruits, vegetables, nuts, seeds or plant foods cooked at
            temperatures below 118°F (48°C) (1Trusted Source).
            80/10/10: The 80/10/10 diet is a raw-food vegan diet that limits fat-rich plants such as nuts and
            avocados and relies mainly on raw fruits and soft greens instead. Also referred to as the low-fat,
            raw-food vegan diet or fruitarian diet.
            <br><br>
            The starch solution: A low-fat, high-carb vegan diet similar to the 80/10/10 but that focuses on cooked
            starches like potatoes, rice and corn instead of fruit.
            Raw till 4: A low-fat vegan diet inspired by the 80/10/10 and starch solution. Raw foods are consumed
            until 4 p.m., with the option of a cooked plant-based meal for dinner.
            The thrive diet: The thrive diet is a raw-food vegan diet. Followers eat plant-based, whole foods that
            are raw or minimally cooked at low temperatures.
            Junk-food vegan diet: A vegan diet lacking in whole plant foods that relies heavily on mock meats and
            cheeses, fries, vegan desserts and other heavily processed vegan foods.
            Although several variations of the vegan diet exist, most scientific research rarely differentiates
            between different types of vegan diets.

        </p>


    </div>
 <?php include("Footer.php");?>

    </body>
	
    </html>
