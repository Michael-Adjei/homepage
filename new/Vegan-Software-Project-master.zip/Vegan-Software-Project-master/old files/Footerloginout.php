<?php

?>
<footer>
    <h2>Connect with Us</h2>
    <h2> Vegan App, Garthdee House, Garthdee Road, Aberdeen AB10 7AQ</h2>
    <h2>Tel: 0123456789, Email: baz@live.nl </h2>
    <section id="contact" class="section">
        <ul>
            <li><a href="http://www.facebook.com"><img src="./Assets/images/facebooklogo.png" alt="Facebook" width="50"></a></li>
            <li><a href="http://www.twitter.com"><img src="./Assets/images/twitterlogo.png" alt="Twitter" width="50"></a></li>
            <li><a href="http://www.youtube.com"><img src="./Assets/images/youtubelogo.png" alt="Youtube" width="50"></a></li>
        </ul>
    </section>
</footer>